// Spec  -- Test Case
// Suite -- Group of Test cases

import { CalculatorService } from "./calculator.service"

let cs:any;
beforeEach(()=>{
   cs = new CalculatorService();
})

describe("Testing calculator service",()=>{
  it("Should add two numbers",()=>{
    expect(cs.sum(10,20)).toBe(30);
  });

  it("Should subtract two numbers",()=>{
    expect(cs.sub(30,20)).toBe(10);
  });
})