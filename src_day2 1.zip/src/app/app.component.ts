import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  // template:`<h1>Welcome to Angular App</h1><p>This is Paragraph-1</p>
  // <p>This is Paragraph-1</p><p>This is Paragraph-1</p><p>This is Paragraph-1</p>
  // <p>This is Paragraph-1</p><p>This is Paragraph-1</p>
  // <p>This is Paragraph-1</p><p>This is Paragraph-1</p>
  // <p>This is Paragraph-1</p>`,
   styleUrls: ['./app.component.css','./mystyles.component.css'],
  // styles: [
  //         ` p 
  //           { color:blue }
  //         `]
  encapsulation : ViewEncapsulation.None
})
export class AppComponent {
  imageSource="../assets/angular.png";
  width=200;
  height=120;

  message:string='Hello, How are you? ';
  n1:string='';
  n2:string='';
  result:number=0;

  displayMessage()
  {
    alert(`Image Width : ${this.width}, Image Height : ${this.height}`);
  }

  sum()
  {
    this.result=Number(this.n1)+Number(this.n2);
  }
}
