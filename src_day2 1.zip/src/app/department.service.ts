import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  dept=[
    {"deptId":101,"deptName":"IT"},
    {"deptId":102,"deptName":"Account"},
    {"deptId":103,"deptName":"Finanace"}
  ]
  constructor() { }

  getDeptDetails()
  {
    return this.dept;
  }

}
