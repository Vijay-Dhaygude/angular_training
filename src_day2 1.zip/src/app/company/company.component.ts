import { Component } from '@angular/core';
import { EmployeeComponent } from '../employee/employee.component';
import { EmployeeService } from '../employee.service';
import { ProductService } from '../product.service';
import { DepartmentService } from '../department.service';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent {

 // employees:any;
  empData:any;
  deptInfo:any;
  productInfo:any;
  constructor(private es:EmployeeService,private ps:ProductService,private ds:DepartmentService)
  {
   // this.employees=new EmployeeComponent();
  }

  ngOnInit()
  {
    this.empData=this.es.getEmployees();
    this.deptInfo=this.ds.getDeptDetails();
    this.productInfo=this.ps.getProducts();
    //this.empData=this.employees.getEmployee();
  }
}
