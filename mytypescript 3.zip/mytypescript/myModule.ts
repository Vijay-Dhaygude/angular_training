export class Product
{
    getProductDetail()
    {
        return "Product Details";
    }
}