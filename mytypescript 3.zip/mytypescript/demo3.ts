// Abstraction
abstract class Salary
{
    abstract getSalary():number;

    printStars()
    {
        console.log("****************");
    }
}

// Interface 

interface Account
{
    accNo:number;
    accType?:string;
    
    getAccountDetails():string;
}

// Encapsulation
class Employee extends Salary implements Account
{
    getSalary(): number {
        return 10000;
    }
   // member variables
   //empNo:number;
   //empName:string;
   
   // member methods

    constructor(private empNo?:number,protected empName?:string,public city?:string)
    {
        super();
        //console.log("Constructor called..");
    }
    accNo: number;
    //accType: string;

    getAccountDetails(): string 
    {
        return "ACC Details";
    }

   setDetails(empNo:number,empName:string) : void
   {
        this.empNo=empNo;
        this.empName=empName;
   }
   getDetails() : string
   {
        return this.empNo+" "+this.empName;
   }
}

let employee1 = new Employee(101,"Manish");  

//employee1.empNo=103;
// employee1.empName="Sachin";
 employee1.city="Mumbai";

let employee2 : Employee;   
employee2 = new Employee();

//employee1.setDetails(101,"Rohit");
employee2.setDetails(102,"Anil");

console.log("Employee1 : ",employee1.getDetails());
console.log("Employee2 : ",employee2.getDetails());

// Inheritance
 class Manager extends Employee 
 {
    getSalary(): number {
        return 50000;
    }
        setName(m_name:string)
        {
            this.empName=m_name;
        }
 }

 class Developer extends Employee
 {
    getSalary(): number {
        return 20000;
    }
 }

 let manager1 =new Manager();

 manager1.setDetails(201,"Sachin");
 manager1.setName("Saourav");
 console.log("Manager1 : "+manager1.getDetails()+" Manager Salary :"+manager1.getSalary() );

// Polymorphism

let empRef:Employee;

empRef = new Manager();

console.log("Manager Sal : "+empRef.getSalary());

empRef = new Developer();

console.log("Developer Sal : "+empRef.getSalary());

