import { Product } from "./myModule";

let product = new Product();
console.log(product.getProductDetail());