console.log("Welcome to Typescript");

//var v1="Hello";
// v1=100;
// v1=2.1;

var v1=200;
var v1=600;

v1=400;
{
    var v1=300;
    console.log(v1);   // 300
}

console.log(v1);   // 300

/////// let , const

let v2=400;
// let v2=400; // Redeclaration not possible

v2=500;   // Reassignment possible
{
    let v2=300;
    console.log(v2);   // 300
}

console.log(v2);   // 400

console.log(x);
var x;

let y;
console.log(y);

console.log("****************");

console.log("********Const**********");

// const 

const z=20;
// const z=20;
// z=30;

//// Regular Function

display();

function display()
{
    console.log("Display called");
}

// Function Expression

var myfunction = function()
{
    console.log("Function Expression");
}

myfunction();

// Arrow Function => (Flat operator)

var functionExpression = () => console.log("Arrow function called");

functionExpression();

var functionExpression1 = (x : any) => console.log("Arrow function called"+x);

functionExpression1(55);

var cube = (num : number) => num*num*num ;

console.log("Cube : ",cube(4));

// setTimeout(() => {
//     console.log("Hi");
// },2000);

// String 

  var city='Pune';
  var country="India";

  console.log(`${city} , ${country}`);

  var city1=`New Delhi`;

////// Parameter Types ( Optional Parameter ) ? 

function displayDetails(name:string,city ?:string) : void
{
    city ? console.log(name," ",city) : console.log(name);
}

displayDetails("Rohit","Delhi");
displayDetails("Rahul");

// Default Parameter

function displayDetails1(name:string,city :string="Mumbai") : void
{
    console.log(name," ",city);
}

displayDetails1("Suresh");
displayDetails1("Suresh","Pune");

// Rest Argument 

function displayDetails2(name:string,...address:any[]) : void
{
    console.log(name+" "+address.join(" "));
}

//displayDetails2();
displayDetails2("Manish","Hyderabad");
displayDetails2("Sunny","Hyderabad","India",64644);

let cy = ["Delhi","Mumbai","Chennai"];

console.log(cy);

for(let i=0;i<cy.length;i++)
{
    console.log(cy[i]);
}

// for..of

for(let c of cy)
{
    console.log(c);
}

// for..in

for(let c in cy)
{
    // console.log(Number(c)+1," ",cy[c]);
    console.log(+c+1," ",cy[c]);
}

cy.forEach(x=>{
    console.log(x);
})
