import { Component } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent {
  empName:string="Rahul";
  empCity:string="Mumbai";
  today = new Date().toLocaleDateString();
  countries = ["India","England","Australia"];
  dept={
    deptName:"IT",
    location:"Mumbai"
  }
  empData=[
    {"empNo":101,"empName":"Sachin"},
    {"empNo":102,"empName":"Saurav"},
    {"empNo":103,"empName":"Amit"}
  ]
}
