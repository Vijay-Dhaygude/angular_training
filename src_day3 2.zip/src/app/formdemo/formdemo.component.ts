import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-formdemo',
  templateUrl: './formdemo.component.html',
  styleUrls: ['./formdemo.component.css']
})
export class FormdemoComponent {

  productData:any;
  constructor()
  {
    this.productData=new FormGroup({
      productId:new FormControl(),
      productName:new FormControl('',[Validators.required,Validators.minLength(3)]),
      address:new FormGroup({
        city:new FormControl(),
        country:new FormControl()
      })
    })
  }

  addProduct()
  {
    //console.log(this.productData);
    console.log("Product Id      : "+this.productData.value.productId);
    console.log("Product Name    : "+this.productData.value.productName);
    console.log("Product City    : "+this.productData.value.address.city);
    console.log("Product Country : "+this.productData.value.address.country);
  }

  save(formdata:any)
  {
      console.log("Employee Id      : "+formdata.empid);
      console.log("Employee Name    : "+formdata.empname);
      console.log("Employee City    : "+formdata.address.city);
      console.log("Employee Country : "+formdata.address.country);
  }
}
