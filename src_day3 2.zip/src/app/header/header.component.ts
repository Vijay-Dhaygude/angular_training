import { Component } from '@angular/core';
import { DateService } from '../date.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {

  today:any;
  appName:string='';
  constructor(private ds:DateService)
  {

  }
  
  ngOnInit()
  {
    //this.today=this.ds.getDate();
    this.today=new Date();
    this.appName=this.ds.getAppName();
  }

}
