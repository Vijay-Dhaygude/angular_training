import { Component } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent {
   
  EmployeeId:string="Employee Id";
  EmployeeName:string='Employee Name';
  EmployeeSalary:string='Employee Salary';
  Gender:string='Gender';

  empName:string="Rahul";
  empCity:string="Mumbai";
  today = new Date().toLocaleDateString();
  countries = ["India","England","Australia"];
  dept={
    deptName:"IT",
    location:"Mumbai"
  }

  empData:any;

  constructor(private es:EmployeeService)
  {

  }

  ngOnInit()
  {
    this.empData=this.es.getEmployees();
  }
  // empData=[
  //   {"empNo":101,"empName":"Sachin","empSal":20000},
  //   {"empNo":102,"empName":"Saurav","empSal":30000},
  //   {"empNo":103,"empName":"Amit","empSal":40000}
  // ]

  salDisplay:boolean=false;
  tabVal:number=1;

  selectedCountry:string='';
  headingVal:number=15;

  showSalary()
  {
    this.salDisplay=true;
  }

  hideSalary()
  {
    this.salDisplay=false;
  }

  getEmployee()
  {
    return this.empData;
  }
}
