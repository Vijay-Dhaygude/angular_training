import { Component } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent {

  dataToChild:string='';
  dataFromChild:string='';

  sendDatatoChild()
  {
    this.dataToChild="Hello Child";
  }

  receiveFromChild(info:string)
  {
    this.dataFromChild=info;
  }
}
