import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { MydirDirective } from './mydir.directive';
import { CompanyComponent } from './company/company.component';
import { HeaderComponent } from './header/header.component';
import { TitlePipe } from './title.pipe';
import { HttpClientModule } from '@angular/common/http';
import { MobileComponent } from './mobile/mobile.component';
import { CityComponent } from './city/city.component';
import { FormdemoComponent } from './formdemo/formdemo.component';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    ParentComponent,
    ChildComponent,
    MydirDirective,
    CompanyComponent,
    HeaderComponent,
    TitlePipe,
    MobileComponent,
    CityComponent,
    FormdemoComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
