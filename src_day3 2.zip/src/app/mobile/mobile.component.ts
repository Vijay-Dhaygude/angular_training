import { Component } from '@angular/core';
import { MobileDataService } from '../mobile-data.service';

@Component({
  selector: 'app-mobile',
  templateUrl: './mobile.component.html',
  styleUrls: ['./mobile.component.css']
})
export class MobileComponent {

  mobileData:any;

  constructor(private ms:MobileDataService)
  {

  }

  ngOnInit()
  {
    this.ms.getMobileData().subscribe(data=>{
      //console.log(data);
      this.mobileData=data;
    });
  }
}
