import { Directive, ElementRef, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appMydir]'
})
export class MydirDirective {

  constructor(private eleref : ElementRef) { }

    @HostBinding('style.border') border : string='';

  ngOnInit()
  {
      this.eleref.nativeElement.style.color='red';
      this.eleref.nativeElement.style.background='yellow';
      this.eleref.nativeElement.style.fontSize='20px';
      this.border='5px dashed blue';
  }

    @HostListener('mouseover') mouseOver()
    {
      this.border='8px solid red';
    }

    @HostListener('mouseleave') mouseleave()
    {
      this.border='5px dashed blue';
    }
}
