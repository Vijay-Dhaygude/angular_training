import { Injectable } from '@angular/core';
import { AppNameService } from './app-name.service';

@Injectable({
  providedIn: 'root'
})
export class DateService {

  day:any;
  month:any;
  year:any;

  constructor(private as:AppNameService) { }

  getDate()
  {
    this.day=new Date().getDate();
    this.month=new Date().getMonth()+1;
    this.year=new Date().getFullYear();

    return this.day+"-"+this.month+"-"+this.year;
  }

  getAppName()
  {
    return this.as.getAppName();
  }
}
