import { Component } from '@angular/core';
import { CityService } from '../city.service';

@Component({
  selector: 'app-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.css']
})
export class CityComponent {

  cityData:any;
  constructor(private cs:CityService)
  {

  }

  ngOnInit()
  {
    this.cs.getCityInfo().subscribe(data=>{
      this.cityData=data;
    })
  }

  postData()
  {
    this.cs.postCityInfo().subscribe(data=>{
      console.log(data+"Data Inserted");
    })
  }
}
