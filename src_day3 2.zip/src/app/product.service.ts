import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  products=[
    {"pid":201,"pName":"Laptop","pCost":20000},
    {"pid":202,"pName":"Mobile","pCost":25000},
    {"pid":203,"pName":"Chair","pCost":30000}
  ]
  constructor() { }

  getProducts()
  {
    return this.products;
  }
}
