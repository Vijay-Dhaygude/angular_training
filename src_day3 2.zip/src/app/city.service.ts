import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CityService {

  constructor(private httpclient:HttpClient) { }

  getCityInfo()
  {
    return this.httpclient.get("http://localhost:3000/cities");
  }

  postCityInfo()
  {
    var city= {"id":206,"cityName":"Bengaluru","cityTemp":55};
    return this.httpclient.post("http://localhost:3000/cities",city);
  }
}
