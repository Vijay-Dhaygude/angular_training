import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MobileDataService {

  constructor(private httpclient : HttpClient) { }

  getMobileData()
  {
    return this.httpclient.get("http://localhost:4200/../assets/products.json");
  }
}
