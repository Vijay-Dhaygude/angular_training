import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  empData=[
    {"empNo":101,"empName":"Sachin","empSal":20000,"gender":"Male"},
    {"empNo":102,"empName":"Saurav","empSal":30000,"gender":"Male"},
    {"empNo":103,"empName":"Amit","empSal":40000,"gender":"Male"},
    {"empNo":104,"empName":"Aishwarya","empSal":45000,"gender":"Female"},
    {"empNo":105,"empName":"Deepika","empSal":50000,"gender":"Female"}
  ]

  constructor() { }

  getEmployees()
  {
    return this.empData;
  }

  getEmployeeById(eno:number) : any
  {
    for(let i=0;i<this.empData.length;i++)
    {
      if(this.empData[i].empNo==eno)
        return this.empData[i];
    }
  }
}
