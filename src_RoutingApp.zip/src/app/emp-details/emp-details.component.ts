import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-emp-details',
  templateUrl: './emp-details.component.html',
  styleUrls: ['./emp-details.component.css']
})
export class EmpDetailsComponent {

  empno:any;
  empData:any;
  constructor(private ar:ActivatedRoute,private es:EmployeeService)
  {

  }

  ngOnInit()
  {
    this.ar.params.subscribe(data=>{
       this.empno = Number(data['eid']);

       this.empData = this.es.getEmployeeById(this.empno);
    })
  }

}
