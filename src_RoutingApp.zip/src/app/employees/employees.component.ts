import { Component } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent {

  employees:any;
  constructor(private es:EmployeeService)
  {

  }

  ngOnInit()
  {
    this.employees=this.es.getEmployees();
  }
}
